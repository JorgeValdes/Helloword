
<p><?php _e('Here the content in Ad-minister is listed. Green rows indicate that the content is visible, and red that it is not. Click on the headers to sort the table according to the values of that column. To reverse the order click the arrow. To edit content click on the title.', 'ad-minister'); ?></p>

<div id="ads">
	<?php administer_stats(); ?>
</div>