<?php get_header(); ?>
<?php 
	$sliderposts = get_option('lu_show_slider');
?>
<div id="main_content">
	<div id="wrapper">
		<?php if ($sliderposts== "true") : ?>
            <div id="slider-wrap">
                <div id="slider">
                    <?php
                    $featurecat = get_option('lu_featured_cat',true);
                    $postnumber = get_option('lu_post_number',true);
                    $tmp = $wp_query;
                    $wp_query = new WP_Query('posts_per_page='.$postnumber.'&category_name='.$featurecat);
                    if(have_posts()) :
                        while(have_posts()) :
                            the_post();
                    ?>
                                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'featured-post-thumbnail', array( 'alt' => get_the_title(), 'title'	=> get_the_title()) ); ?></a>
                    <?php
                        endwhile;
                    endif;
                    $wp_query = $tmp;
                    ?>
                </div>
                <br clear="all" />
             </div><!-- end slider -->
         <?php endif; ?>
         <div id="primary">
            <?php if(have_posts()) : while(have_posts()) : the_post(); ?>
            
            <div class="post_entry">
            <h1 class="post_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
            <p class="info"><a href="<?php comments_link(); ?>"><?php comments_number('0 comments', '1 comment', '% comments'); ?></a> // in <?php the_category(' '); ?> // <?php the_date(); ?></p>
            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
            <?php the_content('Continue Reading &rarr; '); ?>
            </div><!-- end post item -->
            
            <?php endwhile; ?>
            <?php else : ?>
                <h1>Umm... what you looking for?</h1>
            <?php endif; ?>
            
            <?php wp_pagenavi(); ?>
        </div><!-- end primary content -->
    </div><!-- end wrapper (for slider) -->
    <?php get_sidebar (); ?>
</div><!-- end main content -->

<?php get_footer(); ?>