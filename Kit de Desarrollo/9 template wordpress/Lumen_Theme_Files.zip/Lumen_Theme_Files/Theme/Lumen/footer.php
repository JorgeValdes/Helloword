<div id="footer_bg">
<div id="footer"> 

<?php
$footertext = stripslashes(get_option('lu_footer_text'));
$ga = stripslashes(get_option('lu_ga_code'));
?>
	<ul id="footer_left">
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Left Footer") ) : ?>
        <?php endif; ?>
    </ul><!-- end left footer -->
    <ul id="footer_center">
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Center Footer") ) : ?>
        <?php endif; ?>
    </ul><!-- end center footer -->
    <ul id="footer_right">
        <?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Right Footer") ) : ?>
        <?php endif; ?>
    </ul><!-- end right footer -->
</div><!-- end footer -->
</div><!-- end footer background -->
<div id="credits_bg">
	<div id="credits">
    	<div id="copyright">
            <?php if ($footertext) : ?>
			<?php echo $footertext; ?>
        	<?php else : ?>
        	Copyright &copy; 2010 <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>, All rights Reserved.  Made with valid <a href="http://validator.w3.org/check/referer">XHTML</a>.
        	<?php endif; ?>
        </div><!-- end copyright -->
        <div id="top_link">
        	<a href="#top" class="scroll">Back to Top.</a>
        </div><!-- end top link -->
    </div><!-- end credits -->
</div><!-- end credits background -->

<?php wp_footer(); ?>

<?php if ($ga) : ?><?php echo $ga ?><?php endif; ?>
<script src="<?php bloginfo('template_directory'); ?>/inc/jquery.nivo.slider.js" type="text/javascript"></script>
<script type="text/javascript">
	$(window).load(function() {
		$('#slider').nivoSlider({
			effect:'<?php echo(get_option('lu_anim')); ?>', //Specify sets like: 'fold,fade,sliceDown'
			animSpeed:<?php echo(get_option('lu_animspeed')); ?>, //Slide transition speed
			pauseTime:<?php echo(get_option('lu_pausetime')); ?>,
		});
	});
</script>
<script type="text/javascript">
$(document).ready(function() {
   
    $('a[href=#top]').click(function(){
        $('html, body').animate({scrollTop:0}, 'medium');
        return false;
    });

});
</script>
</body>
</html>