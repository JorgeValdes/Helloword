$(document).ready(function(){

    $("a.portfolio_full").fancybox({
         'transitionIn'	:	'elastic',
		 'transitionOut':	'fade',
		 'titlePosition':   'inside',
		 'speedIn'		:	150, 
		 'speedOut'		:	100, 
    });

});