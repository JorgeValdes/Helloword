<?php get_header(); ?>

<div id="main_content">
	<div id="primary">
    	<?php if(have_posts()) : while(have_posts()) : the_post(); ?>
        
    	<div class="post_entry">
        <h1 class="post_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
        <?php the_content(); ?>
        </div><!-- end post item -->
        
        <?php endwhile; ?>
        <?php else : ?>
        	<h1>Umm... what you looking for?</h1>
        <?php endif; ?>
        
        <?php wp_pagenavi(); ?>
    </div><!-- end primary content -->
    <?php get_sidebar (); ?>
</div><!-- end main content -->

<?php get_footer(); ?>