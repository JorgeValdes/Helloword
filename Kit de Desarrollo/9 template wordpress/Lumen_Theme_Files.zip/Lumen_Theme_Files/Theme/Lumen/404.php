<?php get_header(); ?>

<div id="main_content">
	<div id="primary">
        <h1 style="font-size:72px; text-align:center;">404:</h1>
        <h1 style="text-align:center;">Page Not Found!</h1>
        <p style="text-align:center;">Sorry, but the page you are looking for has not been found. Try checking the URL for errors, then hit the refresh button on your browser.</p>
    </div><!-- end primary content -->
    <?php get_sidebar (); ?>
</div><!-- end main content -->

<?php get_footer(); ?>