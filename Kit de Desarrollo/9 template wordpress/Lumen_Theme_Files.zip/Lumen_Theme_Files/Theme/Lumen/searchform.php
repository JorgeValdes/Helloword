<form method="get" id="searchform" action="<?php echo get_bloginfo('url'); ?>">
	<p>
		<input type="text" value="Search..." name="s" id="s" onblur="if (this.value == '') {this.value = 'Search...';}" onfocus="if (this.value == 'Search...') {this.value = '';}"/>
		<input type="submit" value="Search" id="searchsubmit" />
	</p>
</form>