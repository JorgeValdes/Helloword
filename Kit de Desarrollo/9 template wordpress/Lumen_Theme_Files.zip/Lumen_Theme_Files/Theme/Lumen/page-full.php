<?php
/*
Template Name: Full-Width
*/
?>

<?php get_header(); ?>

<div id="main_content">
    <div id="full_wrap">
            <?php if(have_posts()) : while(have_posts()) : the_post(); ?>
            <h1 class="post_title"><?php the_title(); ?></h1>
            <?php the_content(); ?>        
            <?php endwhile; ?>
            <?php else : ?>
                <h1>Umm... what you looking for?</h1>
            <?php endif; ?>
    </div><!-- end page -->
</div><!-- end main content -->

<?php get_footer(); ?>