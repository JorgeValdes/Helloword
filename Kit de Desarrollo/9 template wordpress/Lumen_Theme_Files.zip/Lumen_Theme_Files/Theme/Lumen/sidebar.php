<div id="sidebar">
    <ul>		
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar("Sidebar") ) : ?>

        	<p> This can be used as a DYNAMIC sidebar </p>
        
    	<?php endif; ?>
    </ul>
</div><!-- end secondary content -->