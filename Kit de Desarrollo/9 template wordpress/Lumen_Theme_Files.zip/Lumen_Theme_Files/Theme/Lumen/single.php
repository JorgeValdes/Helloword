<?php get_header(); ?>

<div id="main_content">
	<div id="primary">
    	<?php if(have_posts()) : while(have_posts()) : the_post(); ?>
        
        <?php 
		$showbm = get_option('lu_socialbm');
		$showbio = get_option('lu_aut_bio'); 
		$showrelated = get_option('lu_rel_posts');
		?>

        
    	<div class="post_entry">
        <h1 class="post_title"><?php the_title(); ?></h1>
        <p class="info"><a href="<?php comments_link(); ?>"><?php comments_number('0 comments', '1 comment', '% comments'); ?></a> // in <?php the_category(' '); ?> // <?php the_date(); ?></p>
        <?php the_post_thumbnail( 'single-post-thumbnail' ); ?>
        <?php the_content(); ?>
        </div><!-- end post item -->
        
        <?php endwhile; ?>
        <?php else : ?>
        	<h1>Umm... what you looking for?</h1>
        <?php endif; ?>
        <?php if ($showbm== "true") : ?>
        <div id="social" class="clearfix">
		<h5>Share the Post</h5>
			<a href="<?php bloginfo('rss2_url'); ?>" title="Subscribe to our RSS feed.">
  				<img src="<?php bloginfo('template_directory'); ?>/images/rss_32.png" alt="Subscribe to our RSS feed." />
 			</a>
            <a href="http://twitter.com/home/?status=<?php the_title(); ?> : <?php echo get_tiny_url(get_permalink($post->ID)); ?>" title="Tweet this!">
				<img src="<?php bloginfo('template_directory'); ?>/images/twitter_32.png" alt="Tweet this!" />
			</a>
            <a href="http://www.stumbleupon.com/submit?url=<?php the_permalink(); ?>&amp;amp;title=<?php the_title(); ?>" title="StumbleUpon.">
            	<img src="<?php bloginfo('template_directory'); ?>/images/stumbleupon_32.png" alt="StumbleUpon" />
            </a>
            <a href="http://www.reddit.com/submit?url=<?php the_permalink(); ?>&amp;amp;title=<?php the_title(); ?>" title="Vote on Reddit.">
            	<img src="<?php bloginfo('template_directory'); ?>/images/reddit_32.png" alt="Reddit" />
            </a>
            <a href="http://digg.com/submit?phase=2&amp;amp;url=<?php the_permalink(); ?>&amp;amp;title=<?php the_title(); ?>" title="Digg this!">
            	<img src="<?php bloginfo('template_directory'); ?>/images/digg_32.png" alt="Digg This!" />
            </a>
            <a href="http://del.icio.us/post?url=<?php the_permalink(); ?>&amp;amp;title=<?php the_title(); ?>" title="Bookmark on Delicious.">
            	<img src="<?php bloginfo('template_directory'); ?>/images/delicious_32.png" alt="Bookmark on Delicious" />
            </a>
            <a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;amp;t=<?php the_title(); ?>" title="Share on Facebook.">
            	<img src="<?php bloginfo('template_directory'); ?>/images/facebook_32.png" alt="Share on Facebook" />
            </a>
        </div><!-- end social bookmarks -->
        <?php else : ?>
        <?php endif; ?>
        <?php if ($showbio== "true") : ?>
   	  <div id="author_bio" class="clearfix"> <!-- Start Author Bio -->
            	<h5>About the Author</h5>
				<?php echo get_avatar( get_the_author_email(), '100' ); ?>
		<p><?php  the_author_description(); ?></p>
          <h6>Written by: <?php the_author_posts_link(); ?>  |  <a class="website" href="<?php the_author_meta('user_url'); ?>">Visit Website</a></h6>
          <span></span>
		</div><!-- End Author Bio -->
        <?php else : ?>
        <?php endif; ?>
        
		<?php if ($showrelated== "true") : ?>
         <?php $orig_post = $post;
		global $post;
		$tags = wp_get_post_tags($post->ID);
		if ($tags) {
		$tag_ids = array();
		foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
		$args=array(
		'tag__in' => $tag_ids,
		'post__not_in' => array($post->ID),
		'posts_per_page'=>5, // Number of related posts that will be shown.
		'caller_get_posts'=>1
		);
		$my_query = new wp_query( $args );
		if( $my_query->have_posts() ) {
	
		echo '<div id="relatedposts" class="clearfix"><h5>Related Posts</h5><ul>';
	
		while( $my_query->have_posts() ) {
		$my_query->the_post(); ?>
	
		<li><div class="relatedpost">
        <div class="relatedthumb"><a href="<? the_permalink()?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_post_thumbnail( 'small-thumb' ); ?></a></div>
		<div class="relatedcontent">
		<strong><a href="<? the_permalink()?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></strong>
        <br />
		<?php the_time('M j, Y') ?>
		</div>
        </div>
		</li>
		<? }
		echo '</ul></div>';
		}
		}
		$post = $orig_post;
		wp_reset_query(); ?>
        <?php else : ?>
        <?php endif; ?>
    
        <div id="comments_template"> 
		<?php comments_template(); ?> <!-- end comments -->
		</div>
    </div><!-- end primary content -->
    <?php get_sidebar (); ?>
</div><!-- end main content -->

<?php get_footer(); ?>