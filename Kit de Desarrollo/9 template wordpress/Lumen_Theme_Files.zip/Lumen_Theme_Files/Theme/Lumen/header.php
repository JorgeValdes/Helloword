<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
    <meta name="generator" content="Wordpress <?php bloginfo('version'); ?>" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php bloginfo('name'); ?> <?php wp_title(); ?></title>
    <link rel="pingback" href="<?php bloginfo('pingback url'); ?>" />
    <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" />
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/styles/superfish.css" />
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/styles/<?php echo strtolower(get_option('lu_color')); ?>.css" type="text/css" media="screen" />	
    <link rel="shortcut icon" href="<?php echo get_option('lu_favicon'); ?>" />
    <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery-1.4.4.min.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/hoverIntent.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/superfish.js"></script>
    <script type="text/javascript">
		// initialise plugins
		$(document).ready(function() { 
        $('ul.sf-menu').superfish({ 
            delay:       150,                            // one second delay on mouseout 
            animation:   {opacity:'show',height:'show'},  // fade-in and slide-down animation 
            speed:       'fast',                          // faster animation speed 
            autoArrows:  false,                           // disable generation of arrow mark-up 
            dropShadows: false                            // disable drop shadows 
        }); 
    }); 
	</script>
    
    <style type="text/css">
	<?php echo get_option('lu_custom_css'); ?>
	</style>
    
    <?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
    <?php wp_head(); ?>
    
    <!--[if IE 6]>
		<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/ie6.css" />
	<![endif]-->
	<!--[if lt IE 8]>
		<script src ="http://ie7-js.googlecode.com/svn/version/2.1(beta2)/IE8.js"></script>
	<![endif]-->
    
</head>

<body>
<?php
$twitter = stripslashes(get_option('lu_twitter_username'));
$email = stripslashes(get_option('lu_email_adress'));
$showad = get_option('lu_banner_ad');
$banurl = stripslashes(get_option('lu_banner_url'));
$banimg = stripslashes(get_option('lu_banner_img'));
?>
<div id="header_bg">
<div id="header">
<div id="top_lvl">
	<?php wp_nav_menu(array('menu' => 'Links')); ?><!-- end top menu items -->
	<div class="sub_links">
        	<?php if ($twitter) : ?><a class="twit_ico" href="http://twitter.com/<?php echo $twitter; ?>">Twitter</a><?php endif; ?>
            <?php if ($email) : ?><a class="mail_ico" href="mailto:<?php echo $email; ?>">E-mail</a><?php endif; ?>
            <a class="rss_ico" href="<?php bloginfo('rss2_url'); ?>">RSS</a>
   	</div> <!-- end subscription links -->
</div><!-- end Top Level -->
<div id="logo">
    <a href="<?php bloginfo('url'); ?>"><img class="logo" src="<?php echo(get_option('lu_logo'));?>" alt="<?php bloginfo('name'); ?> logo"/></a>
</div><!-- end logo -->
<?php if ($showad== "true") : ?>
<div id="banner_ad">
    <a href="<?php echo $banurl ?>"><img class="banner_ad" src="<?php echo $banimg ?>" alt="banner ad" /></a>
</div><!-- end banner ad -->
<?php else : ?>
<?php endif; ?>
</div><!-- end header content -->
</div><!-- end header bg -->
<div id="main_navigation">
<?php wp_nav_menu(array('menu' => 'Navigation', 'menu_class' => 'sf-menu clearfix')); ?><!-- end menu items -->
</div><!-- end main navigation -->