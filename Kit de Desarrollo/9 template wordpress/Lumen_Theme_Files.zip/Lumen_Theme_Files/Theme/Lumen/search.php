<?php get_header(); ?>

<div id="main_content">
	<div id="primary">
    	<?php if(have_posts()) : while(have_posts()) : the_post(); ?>
        
    	<div class="post_entry">
        <h1 class="post_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
        <p class="info"><a href="<?php comments_link(); ?>"><?php comments_number('0 comments', '1 comment', '% comments'); ?></a> // in <?php the_category(' '); ?> // <?php the_date(); ?></p>
        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
        <?php the_content('Continue Reading &rarr; '); ?>
        </div><!-- end post item -->
        
        <?php endwhile; ?>
        <?php else : ?>
        	<h1>Sorry there were no matches to your search.</h1>
        <?php endif; ?>
        
        <?php wp_pagenavi(); ?>
    </div><!-- end primary content -->
    <?php get_sidebar (); ?>
</div><!-- end main content -->

<?php get_footer(); ?>