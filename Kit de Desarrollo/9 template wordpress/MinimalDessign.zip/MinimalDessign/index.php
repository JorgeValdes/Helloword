<?php get_header(); ?>
    
    <div id="content">
    
      <div class="content_left">

       <?php
         global $post;
         $myposts = get_posts('numberposts=20&category_name=Featured Big');
         foreach($myposts as $post) :
           setup_postdata($post);
         ?>
         
        <div class="post_big">
        
        <?php
        if ( has_post_thumbnail() ) {
          ?> <span class="home_image"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('featured-big'); ?></a></span> <?php
        } else {
          ?> <span class="home_image"><a href="<?php the_permalink(); ?>"><img src="<?php echo catch_that_image() ?>" width="500" height="233" /></a></span> <?php
        }
        ?>
          
           <p><?php $temp_arr_content = explode(" ",substr(strip_tags(get_the_content()),0,290)); $temp_arr_content[count($temp_arr_content)-1] = ""; $display_arr_content = implode(" ",$temp_arr_content); echo $display_arr_content; ?><?php if(strlen(strip_tags(get_the_content())) > 290) echo "..."; ?></p>
          
        </div><!--//post_big-->

       <?php endforeach; ?>
        
      </div><!--//content_left-->
      
      <div class="content_right">
      
       <?php
         global $post;
         $myposts = get_posts('numberposts=20&category_name=Featured Medium');
         foreach($myposts as $post) :
           setup_postdata($post);
         ?>
         
        <div class="post_medium">
          <?php
          if ( has_post_thumbnail() ) {
            ?> <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('featured-medium'); ?></a> <?php
          } else {
            ?> <a href="<?php the_permalink(); ?>"><img src="<?php echo catch_that_image() ?>" width="158" height="200" /></a> <?php
          }
          ?>

        </div><!--//post_medium-->

       <?php endforeach; ?>
      
      </div><!--//content_right-->
    
    </div><!--//content-->
  
  </div><!--//left_container-->
  
  <div class="right_container">
  
    <div class="right_sidebar">
    
       <?php
         global $post;
         $myposts = get_posts('numberposts=20&category_name=Featured Small');
         foreach($myposts as $post) :
           setup_postdata($post);
         ?>
         
          <?php
          if ( has_post_thumbnail() ) {
            ?> <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('featured-small'); ?></a> <?php
          } else {
            ?> <a href="<?php the_permalink(); ?>"><img src="<?php echo catch_that_image() ?>" width="172" height="104" /></a> <?php
          }
          ?>
  

       <?php endforeach; ?>
        
    </div><!--//right_sidebar-->
  
  </div><!--//right_container-->
  
<?php get_footer(); ?>