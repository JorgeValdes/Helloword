<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml">
<head> 
  <title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>
  <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" title="no title" charset="utf-8"/>
  <?php wp_head(); ?>
</head>
<body>

<div id="main_container">

  <div class="left_container">

    <div id="header">
    
      <div class="header_first">
        <a href="/"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/logo.jpg" /></a>
      </div><!--//header_first-->
      
      <div class="header_second">
        <ul>
          <li>Mike Kikuchi</li>
          <li>1980.10.21/Designer Born in</li> 
          <li>Vienna Living in London</li>
          <li>234.345.5645</li>
        </ul>
      </div><!--//header_second-->
      
      <div class="header_third">
        <ul>
          <li><a href="http://www.twitter.com">Twitter</a></li>
          <li><a href="http://www.facebook.com">Facebook</a></li>
          <li><a href="http://www.tumblr.com">Tumblr</a></li>
          <li><a href="http://www.flickr.com">Flickr</a></li>
        </ul>
      </div><!--//header_third-->
      
      <div class="clear"></div>
      
      <div id="menu">
        <ul>
          <li><a href="/">HOME</a></li>
          <li><a href="/about/">ABOUT</a></li>
          <li><a href="/portfolio/">PORTFOLIO</a></li>
          <li><a href="/services/">SERVICES</a></li>
          <li><a href="/blog/">BLOG</a></li>
          <li><a href="/contact/">CONTACT</a></li>
        </ul>
      </div>
    
    </div><!--//header-->
    
    <div class="clear"></div>