<?php get_header(); ?>
    
    <div id="content">
    
      <div class="content_left">
        
        <div class="post_big">
        
          <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
          
            <?php the_content(); ?>
            
            <br /><br />
            
            <div class="comments">
              <?php comments_template(); ?>
            </div><!--//comments-->
            
          <?php endwhile; else: ?>
      
            <h3>Sorry, no posts matched your criteria.</h3>
        
          <?php endif; ?>
          
        </div><!--//post_big-->
        
      </div><!--//content_left-->
      
      <div class="content_right">
      
       <?php
         global $post;
         $myposts = get_posts('numberposts=20&category_name=Featured Medium');
         foreach($myposts as $post) :
           setup_postdata($post);
         ?>
         
        <div class="post_medium">
          <?php
          if ( has_post_thumbnail() ) {
            ?> <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('featured-medium'); ?></a> <?php
          } else {
            ?> <a href="<?php the_permalink(); ?>"><img src="<?php echo catch_that_image() ?>" width="158" height="200" /></a> <?php
          }
          ?>
        </div><!--//post_medium-->

       <?php endforeach; ?>
      
      </div><!--//content_right-->
    
    </div><!--//content-->
  
  </div><!--//left_container-->
  
  <div class="right_container">
  
    <div class="right_sidebar">
    
       <?php
         global $post;
         $myposts = get_posts('numberposts=20&category_name=Featured Small');
         foreach($myposts as $post) :
           setup_postdata($post);
         ?>
         
          <?php
          if ( has_post_thumbnail() ) {
            ?> <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('featured-small'); ?></a> <?php
          } else {
            ?> <a href="<?php the_permalink(); ?>"><img src="<?php echo catch_that_image() ?>" width="172" height="104" /></a> <?php
          }
          ?>
  

       <?php endforeach; ?>
        
    </div><!--//right_sidebar-->
  
  </div><!--//right_container-->
  
<?php get_footer(); ?>