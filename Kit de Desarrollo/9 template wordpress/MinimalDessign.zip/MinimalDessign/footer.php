  <div class="clear"></div>
  
  <div id="footer">
    Copyright 2011. All Rights Reserved. Design & Developed by <a href="http://www.dessign.net">Dessign.net</a>
  </div><!--//footer-->
  
</div><!--//main_container-->

<?php wp_footer(); ?>
</body>
</html>
