<?php
/*
  Template Name: Blog
*/
?>

<?php get_header(); ?>
    
    <div id="content">
    
      <div class="content_left">
      
      
<?php
      $args = array(
                   'category_name' => 'blog',
                   'post_type' => 'post',
                   'posts_per_page' => 10,
                   'paged' => ( get_query_var('paged') ? get_query_var('paged') : 1),
                   );

      query_posts($args);
      while (have_posts()) : the_post(); ?>
        
        <div class="post_big">
        
          <?php
          if ( has_post_thumbnail() ) {
            ?> <span class="blog_img_size"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('featured-blog'); ?></a></span> <?php
          } else {
            ?> <a href="<?php the_permalink(); ?>"><img src="<?php echo catch_that_image() ?>" class="blog_image" /></a> <?php
          }
          ?>
          
          
          <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
          
          <p><?php $temp_arr_content = explode(" ",substr(strip_tags(get_the_content()),0,290)); $temp_arr_content[count($temp_arr_content)-1] = ""; $display_arr_content = implode(" ",$temp_arr_content); echo $display_arr_content; ?><?php if(strlen(strip_tags(get_the_content())) > 290) echo "..."; ?></p>
          
        </div><!--//post_big-->
        
        
      <?php endwhile; ?>
        <div class="clear"></div>
        <div class="left"><?php previous_posts_link('&laquo; Previous') ?></div>
        <div class="right"><?php next_posts_link('More &raquo;') ?></div>
      <?php wp_reset_query(); ?>

        
      </div><!--//content_left-->
      
      <div class="content_right">
      
       <?php
         global $post;
         $myposts = get_posts('numberposts=20&category_name=Featured Medium');
         foreach($myposts as $post) :
           setup_postdata($post);
         ?>
         
        <div class="post_medium">
          <?php
          if ( has_post_thumbnail() ) {
            ?> <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('featured-medium'); ?></a> <?php
          } else {
            ?> <a href="<?php the_permalink(); ?>"><img src="<?php echo catch_that_image() ?>" width="158" height="200" /></a> <?php
          }
          ?>
        </div><!--//post_medium-->

       <?php endforeach; ?>
      
      </div><!--//content_right-->
    
    </div><!--//content-->
  
  </div><!--//left_container-->
  
  <div class="right_container">
  
    <div class="right_sidebar">
    
       <?php
         global $post;
         $myposts = get_posts('numberposts=20&category_name=Featured Small');
         foreach($myposts as $post) :
           setup_postdata($post);
         ?>
         
          <?php
          if ( has_post_thumbnail() ) {
            ?> <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('featured-small'); ?></a> <?php
          } else {
            ?> <a href="<?php the_permalink(); ?>"><img src="<?php echo catch_that_image() ?>" width="172" height="104" /></a> <?php
          }
          ?>
  

       <?php endforeach; ?>
        
    </div><!--//right_sidebar-->
  
  </div><!--//right_container-->
  
<?php get_footer(); ?>