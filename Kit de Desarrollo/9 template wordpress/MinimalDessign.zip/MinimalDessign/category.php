<?php
/*
  Template Name: Portfolio
*/
?>

<?php get_header(); ?>
    
    <div id="content">
    
       <?php
         global $post;
         $x = 0;
         $myposts = get_posts('numberposts=20&category_name=Portfolio');
         foreach($myposts as $post) :
           setup_postdata($post);
         ?>
         
        <div class="portfolio_post <?php if($x == 0) { echo "left"; } else { echo "right"; } ?>">
        
        <?php
        if ( has_post_thumbnail() ) {
          ?> <span class="category_image"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('featured-category'); ?></a></span> <?php
        } else {
          ?> <a href="<?php the_permalink(); ?>"><img src="<?php echo catch_that_image() ?>" width="327" height="284" /></a> <?php
        }
        ?>
        
        </div><!--//portfolio_post-->
        
        <?php $x++; ?>
        <?php if($x == 2) { $x=0; } ?>

       <?php endforeach; ?>
        
      

    </div><!--//content-->
  
  </div><!--//left_container-->
  
  <div class="right_container">
  
    <div class="right_sidebar">
    
       <?php
         global $post;
         $myposts = get_posts('numberposts=20&category_name=Featured Small');
         foreach($myposts as $post) :
           setup_postdata($post);
         ?>
         
          <?php
          if ( has_post_thumbnail() ) {
            ?> <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('featured-small'); ?></a> <?php
          } else {
            ?> <a href="<?php the_permalink(); ?>"><img src="<?php echo catch_that_image() ?>" width="172" height="104" /></a> <?php
          }
          ?>
  

       <?php endforeach; ?>
        
    </div><!--//right_sidebar-->
  
  </div><!--//right_container-->
  
<?php get_footer(); ?>