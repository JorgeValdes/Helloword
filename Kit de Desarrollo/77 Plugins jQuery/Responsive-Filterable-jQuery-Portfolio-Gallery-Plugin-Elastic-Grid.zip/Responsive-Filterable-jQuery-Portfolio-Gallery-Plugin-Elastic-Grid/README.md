# jQuery Elastic Grid

jQuery Elastic Grid is a lightweight, easy to use gallery jquery plugin script inspired by Google Image Search with support for .PNG, .JPG and .GIF image files. It uses a thumbnail grid with expanding preview for displaying your images. It is also fully HTML5 and CSS3 compliant.

Find out more here: http://demo.phapsu.com/jquery.elastic_grid/index.php
