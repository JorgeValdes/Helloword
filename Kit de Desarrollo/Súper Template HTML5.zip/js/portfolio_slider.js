$(function(){
$("#proyectos").elastic_grid({	
	'hoverDirection': true,
	'hoverDelay': 0,
	'hoverInverse': false,
	'expandingSpeed': 500,
	'expandingHeight': 500,
	'items' :
		[
			{
			'title' : 'ALTO DEL BOSQUE',
            'description' : '<span><h5>FICHA TÉCNICA</h5> <strong>Contratante:</strong><br>Ing. Fernando Velandia.<br>Ing. Viviana Bustamante.<br><strong>Fecha:</strong> Diciembre 2010<br>Área de lote:</strong> 5,486,65m2<br><strong>Área de construcción:</strong> 15,960,9 m2</span> <span>El proyecto esta localizado en el terreno No 9 del sector unión nacional con No predial 644279 en la ciudad de Quito-Ecuador. Terreno que se caracteriza por su inclinación al ser montañoso, cabe resaltar que se encuentra a pocos minutos del aeropuerto internacional Mariscal Sucre de Quito.</span> ',
			'thumbnail' : 
                [
                    'img/proyectos/peque/p-altobosque1.jpg',
                    'img/proyectos/peque/p-altobosque2.jpg',
                    'img/proyectos/peque/p-altobosque3.jpg',
                    'img/proyectos/peque/p-altobosque4.jpg',
                    'img/proyectos/peque/p-altobosque5.jpg',
                    'img/proyectos/peque/p-altobosque6.jpg',
                    'img/proyectos/peque/p-altobosque7.jpg'
                    
                ],
			'large' : 
                [
                    'img/proyectos/grande/g-altobosque1.jpg',
                    'img/proyectos/grande/g-altobosque2.jpg',
                    'img/proyectos/grande/g-altobosque3.jpg',
                    'img/proyectos/grande/g-altobosque4.jpg',
                    'img/proyectos/grande/g-altobosque5.jpg',
                    'img/proyectos/grande/g-altobosque6.jpg',
                    'img/proyectos/grande/g-altobosque7.jpg'
                ],
			'button_list'   : false,
			'tags'  : ['Todo']
			},
            
            {
			'title' : 'ALKIMIA APARTAMENTOS',
            'description' : '<span><h5>FICHA TÉCNICA</h5> <strong>Contratante:</strong><br>Constructora Arawak Ltda.<br><strong>Fecha:</strong> Febrero 2011<br><strong>Gerente:</strong> Marta Velandia</span> <span>EL proyecto esta localizado en la calle 20 No 4-50 en el municipio de Mosquera Cundinamarca. Diseño arquitectónico y urbano de ALQUIMIA APARTAMENTS, la cual cuenta con 6.670 m2 de lote y de construcción 15,830,46 para el uso de vivienda multifamiliar de 8 pisos, además la representación digital en 3dmax mental ray.</span> ',
			'thumbnail' : ['img/proyectos/peque/p-alkimia1.jpg'],
			'large' : ['img/proyectos/grande/g-alkimia1.jpg'],
			/*'button_list'   :
			[
			{ 'title':'Leer más', 'url' : 'http://#' },
			],*/'button_list'   : false,
			'tags'  : ['Todo']
			},            
            
            {
			'title' : 'SUBALLANO',
            'description' : '<span><h5>FICHA TÉCNICA</h5> <strong>Contratante:</strong><br>Arq. Ferney Barreto<br><strong>Fecha:</strong> Mayo 2011</span> <span>El proyecto esta localizado hacia Las afueras de Yopal vía a Aguazul Casanare. El proyecto consiste en realizar una edificación para la subasta ganadera del Casanare Representación en renders del proyecto</span> ',
			'thumbnail' : [
                            'img/proyectos/peque/p-suballano1.jpg',
                            'img/proyectos/peque/p-suballano2.jpg'
                          ],
			'large' : [
                        'img/proyectos/grande/g-suballano1.jpg',
                        'img/proyectos/grande/g-suballano2.jpg'
                      ],
			/*'button_list'   :
			[
			{ 'title':'Leer más', 'url' : 'http://#' },
			],*/'button_list'   : false,
			'tags'  : ['Todo']
			},
            
            {
			'title' : 'QUINTAS DE ZARASOTA',
            'description' : '<span><h5>FICHA TÉCNICA</h5> <strong>Contratante:</strong><br>Constructora Arawak Ltda.<br>Unión temporal el diamante.<br><strong>Fecha:</strong> Enero 2010<br><strong>Gerente:</strong> Marta Velandia </span> <span>El proyecto esta localizado en el sector del diamante en el municipio de Mosquera – Cundinamarca. Se caracteriza por ser casas de 3 pisos estilo campestre, además cabe resaltar que están a 5 min de Bogotá..</span> ',
			'thumbnail' : [
                            'img/proyectos/peque/p-zarasota1.jpg',
                            'img/proyectos/peque/p-zarasota2.jpg',
                            'img/proyectos/peque/p-zarasota3.jpg',
                            'img/proyectos/peque/p-zarasota4.jpg',
                            'img/proyectos/peque/p-zarasota5.jpg'
                          ],
			'large' : [
                        'img/proyectos/grande/g-zarasota1.jpg',
                        'img/proyectos/grande/g-zarasota2.jpg',
                        'img/proyectos/grande/g-zarasota3.jpg',
                        'img/proyectos/grande/g-zarasota4.jpg',
                        'img/proyectos/grande/g-zarasota5.jpg'
                      ],
			/*'button_list'   :
			[
			{ 'title':'Leer más', 'url' : 'http://#' },
			],*/'button_list'   : false,
			'tags'  : ['Todo']
			},/*
            
            {
			'title' : 'Proyecto Casa U',
            'description' : '<span><h5>FICHA TÉCNICA</h5> <strong>Contratante:</strong><br>Luz marina Diazgranados<br><strong>Fecha:</strong> Julio 2012<br><strong>Área de construcción:</strong> 220 m2<br></span> <span>La casa esta localizada en la Kr 1ª N 20-18 en el sector de Rodadero Sur en Santa Marta . Se caracteriza por ser de estilo minimalista de 2 pisos , además cabe resaltar que está a media cuadra de la playa.</span> ',
			'thumbnail' : [
                            'img/proyectos/peque/p-casau1.jpg',
                            'img/proyectos/peque/p-casau2.jpg'
                          ],
			'large' : [
                        'img/proyectos/grande/g-casau1.jpg',
                        'img/proyectos/grande/g-casau2.jpg'
                      ],
			/*'button_list'   :
			[
			{ 'title':'Leer más', 'url' : 'http://#' },
			],'button_list'   : false,
			'tags'  : ['Todo']
			},*/
            
            {
			'title' : 'HACIENDA VILLA ISABEL',
            'description' : '<span><h5>FICHA TÉCNICA</h5> <strong>Contratante:</strong><brIrma Gonzales<br>Jairo Vélez<br><strong>Fecha:</strong> Julio 2012<br></span> <span>EL proyecto esta localizado en el municipio de Restrepo Meta en la vereda el Caney bajo ,finca lote 2B., la cual cuenta con 10 has de lote, de las cuales se desarrollan 5,000 m2 para la realización de las quintas. Estas contaran con piscina privada y un estilo campestre de casa-lote.</span> ',
			'thumbnail' : [
                            'img/proyectos/peque/p-villaisabel1.jpg',
                            'img/proyectos/peque/p-villaisabel2.jpg'
                          ],
			'large' : [
                        'img/proyectos/grande/g-villaisabel1.jpg',
                        'img/proyectos/grande/g-villaisabel2.jpg'
                      ],
			/*'button_list'   :
			[
			{ 'title':'Leer más', 'url' : 'http://#' },
			],*/'button_list'   : false,
			'tags'  : ['Todo']
			}/*,
	 
            {
			'title' : 'CABAÑA VEDISTA',
            'description' : '<span><h5>FICHA TÉCNICA</h5> <strong>Contratante:</strong><br>Orlando Vives Prieto<br><strong>Fecha:</strong> Agosto 2012<br></span> <span>El proyecto esta localizado en el terreno No 9 del sector unión nacional con No predial 644279 en la ciudad de Quito-Ecuador. Terreno que se caracteriza por su inclinación al ser montañoso, cabe resaltar que se encuentra a pocos minutos del aeropuerto internacional Mariscal Sucre de Quito.</span> ',
			'thumbnail' : [
                            'img/proyectos/peque/p-vedista1.jpg'
                          ],
			'large' : [
                        'img/proyectos/grande/g-vedista1.jpg'
                      ],
			/*'button_list'   :
			[
			{ 'title':'Leer más', 'url' : 'http://#' },
			],'button_list'   : false,
			'tags'  : ['Todo']
			}*/
		]
	});
});